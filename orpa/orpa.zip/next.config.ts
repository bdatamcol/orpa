module.exports = {
  output: "export",
  images: {
    unoptimized: true, // Evita problemas con imágenes en modo export
  },
};
